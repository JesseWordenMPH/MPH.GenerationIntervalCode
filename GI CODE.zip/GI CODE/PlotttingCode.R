library(deSolve)
library(ggplot2)
library(reshape2)
library(gridExtra)



#
#
#
# SEIR MODEL
#
#
#
# Function that specifies SEIR differential equations
seir_diff_fn <- function(t, state, parameters) {
  with(as.list(c(state, parameters)), {
    beta <- beta_fn(t)
    sigma <- sigma_fn(t)
    gamma <- gamma_fn(t)
    lambda <- lambda_fn(t)
    
    dS <- -( (beta / N) * S * I ) - lambda * S 
    dE <- (beta / N) * S * I - sigma * E
    dI <- sigma * E - gamma * I
    dR <- gamma * I + lambda * S
    list(c(dS, dE, dI, dR))
  })
}

simulate_seir <- function(initial_value, params, start, end) {
  beta_fn <- approxfun(params$beta_events$time, params$beta_events$value, method="constant", rule=2)
  sigma_fn <- approxfun(params$sigma_events$time, params$sigma_events$value, method="constant", rule=2)
  gamma_fn <- approxfun(params$gamma_events$time, params$gamma_events$value, method="constant", rule=2)
  lambda_fn <- approxfun(params$lambda_events$time, params$lambda_events$value, method="constant", rule=2)
  
  result <- list()
  result$overview <- data.frame(ode(
    y = initial_value,
    func = function(t, state, parameters) {
      seir_diff_fn(t, state, c(parameters, list(beta_fn=beta_fn, sigma_fn=sigma_fn, gamma_fn=gamma_fn, lambda_fn=lambda_fn)))
    },
    times = seq(start, end, by=0.1),
    parms = params
  ))
  
  result$overview <- calculate_incidence(result$overview, list(beta_fn=beta_fn, N=params$N))
  result$params <- params
  
  result$beta <- beta_fn
  result$sigma <- sigma_fn
  result$gamma <- gamma_fn
  result$lambda <- lambda_fn
  
  result$events <- tail(params$beta_events, -1)
  
  result$S <- approxfun(result$overview$time, result$overview$S, yright=0, rule=2)
  result$E <- approxfun(result$overview$time, result$overview$E, rule=2)
  result$I <- approxfun(result$overview$time, result$overview$I, rule=2)
  result$R <- approxfun(result$overview$time, result$overview$R, rule=2)
  result$i <- approxfun(result$overview$time, result$overview$incidence, rule=2)
  
  return(result)
}
calculate_incidence <- function(df, params) {
  beta_fn <- params$beta_fn
  N <- params$N
  df$incidence <- mapply(function(t, S, I) {
    beta <- beta_fn(t)
    (beta * S * I) / N
  }, df$time, df$S, df$I)
  df
}

#
#
#
# GI DIST CALCULATIONS
#
#
#
#Function that calculates the expected values of a probability dist
expectation <- function(fn) {
  integrate(function(x) x * fn(x), 0, 1000)$value
}
intrinsic_gt <- function(t, tau, sigma_fn, gamma_fn) {
  sigma <- sigma_fn(t)
  gamma <- gamma_fn(t)
  
  if (sigma == gamma) {
    # Erlang distribution with k = 2 and rate lambda = sigma = gamma
    result <- (sigma^2) * tau * exp(-sigma * tau)
  } else {
    # Hypoexponential distribution with rates sigma and gamma
    result <- (sigma * gamma) * (exp(-gamma * tau) - exp(-sigma * tau)) / (sigma - gamma)
  }
  
  return(result)
}
#Helper function that performs part of computation for fGI and bGI calculations.
#Define g0_fn allows iGI to be computed without repeatedly needed to specify sigma and gamma.
g0_fn <- function(t, tau) intrinsic_gt(t, tau, simulation$sigma, simulation$gamma)

#Function that returns the forward generation interval distribution.
forward_gt <- function(t, tau, beta_fn, S_fn, g0_fn) {
  num <- g0_fn(t, tau) * beta_fn(t + tau) * S_fn(t + tau)
  denom <- integrate(
    function(rho) g0_fn(t, rho) * beta_fn(t + rho) * S_fn(t + rho),
    0,
    Inf
  )$value
  
  if (denom <= 0) {
    return(0)
  }
  
  num / denom
}

#Function that returns the backwards generation time distribution
backward_gt <- function(t, tau, incidence_fn, g0_fn) {
  num <- g0_fn(t, tau) * incidence_fn(t - tau)
  denom <- integrate(
    function(rho) g0_fn(t, rho) * incidence_fn(t - rho),
    0,
    t
  )$value
  
  if (denom <= 0) {
    return(0)
  }
  
  num / denom
}

#
#
#
# PARAMETER CHANGE CODE
#
#
#
# Function to generate linear change in parameters
linear_change_vars <- function(initial, m, t, i, revert_to_zero = FALSE) {
  timesteps <- seq(0, 400, by = 0.1)
  values <- rep(initial, length(timesteps))
  
  start_index <- which(timesteps >= t)[1]
  
  for (j in 0:(i * 10)) {
    if (start_index + j <= length(timesteps)) {
      values[start_index + j] <- initial + m * j
    }
  }
  
  if (revert_to_zero) {
    if (start_index + i * 10 <= length(timesteps)) {
      values[(start_index + i * 10 + 1):length(timesteps)] <- 0
    }
  } else {
    if (start_index + i * 10 <= length(timesteps)) {
      values[(start_index + i * 10 + 1):length(timesteps)] <- values[start_index + i * 10]
    }
  }
  
  return(data.frame(time = timesteps, value = values))
}

# Generate parameter change data frames for each parameter
generate_parameter_change_df <- function(params) {
  events <- list()
  for (param_name in names(params)) {
    param <- params[[param_name]]
    if (param_name == "lambda") {
      events[[param_name]] <- linear_change_vars(param$initial, param$m, param$t, param$i, revert_to_zero = param$revert_to_zero)
    } else {
      events[[param_name]] <- linear_change_vars(param$initial, param$m, param$t, param$i)
    }
  }
  return(events)
}

#
#
#
# ITERATION CODE
#
#
#
run_simulation_and_calculate_gi_means <- function(param_name, param_value, param_type) {
  if (param_name == "beta") {
    parameters$beta[[param_type]] <- param_value
  } else if (param_name == "sigma") {
    parameters$sigma[[param_type]] <- param_value
  } else if (param_name == "gamma") {
    parameters$gamma[[param_type]] <- param_value
  } else if (param_name == "lambda") {
    parameters$lambda[[param_type]] <- param_value
  }
  
  parameter_change_events <- generate_parameter_change_df(parameters)
  
  # Creating data frames for the events
  beta_events <- parameter_change_events$beta
  sigma_events <- parameter_change_events$sigma
  gamma_events <- parameter_change_events$gamma
  lambda_events <- parameter_change_events$lambda
  
  # Adding parameters to list
  params <- list(
    N = 100000,
    beta_events = beta_events,
    sigma_events = sigma_events,
    gamma_events = gamma_events,
    lambda_events = lambda_events
  )
  
  # Runs the SEIR model with specified parameters/values
  simulation <- simulate_seir(
    initial_value = state,
    params = params,
    start = 0,
    end = 400
  )
  
  # Function to calculate intrinsic generation interval
  g0_fn <- function(t, tau) intrinsic_gt(t, tau, simulation$sigma, simulation$gamma)
  
  # Calculating GI Means
  # Calculate intrinsic mean generation time
  g0_mean <- function(t) expectation(function(tau) g0_fn(t, tau))
  
  # Store in the simulation result for use in other calculations
  simulation$g0 <- g0_fn
  
  # Time points for forward and backward generation times
  gfs <- data.frame(time = seq(0, 250, by = 1))
  
  # Calculate forward and backward generation time means
  gfs$intrinsic <- sapply(gfs$time, g0_mean)
  
  # Forward generation time mean
  gfs$forward <- sapply(gfs$time, function(t) {
    expectation(function(tau) forward_gt(t, tau, simulation$beta, simulation$S, g0_fn))
  })
  
  # Backward generation time mean
  gfs$backward <- sapply(gfs$time, function(t) {
    expectation(function(tau) backward_gt(t, tau, simulation$i, g0_fn))
  })
  
  # Include susceptibility (S) and incidence (i) values
  gfs$S <- sapply(gfs$time, simulation$S)
  gfs$i <- sapply(gfs$time, simulation$i)
  
  return(gfs)
}

library(ggplot2)
library(gridExtra)
library(grid)

plot_gi_means <- function(param_name, param_values, param_type) {
  # Extract the initial parameter value
  initial_value <- parameters[[param_name]]$initial
  
  gi_means_list <- lapply(param_values, function(val) {
    cat("Running simulation for", param_name, param_type, "=", val, "\n")
    run_simulation_and_calculate_gi_means(param_name, val, param_type)
  })
  
  # Remove any gi_means_list values that are NULL or have no data
  gi_means_list <- Filter(function(x) !is.null(x) && nrow(x) > 0, gi_means_list)
  
  if (length(gi_means_list) == 0) {
    cat("No valid data to plot.\n")
    return(NULL)
  }
  
  plot_colors <- c("red", "orange", "blue", "purple", "green") #If doing more than 5 iterations, more colors will need to be added.
  plot_labels <- paste(param_type, "=", param_values[seq_along(gi_means_list)])
  legend_title <- paste(param_name, param_type, "change")
  
  # Create data frames for plotting
  combined_data <- do.call(rbind, lapply(seq_along(gi_means_list), function(i) {
    data <- gi_means_list[[i]]
    data$param_value <- plot_labels[i]
    data
  }))
  
#Plots
  incidence_plot <- ggplot(combined_data, aes(x = time, color = param_value)) +
    geom_line(aes(y = i), size = 0.7) +
    labs(x = "Calendar time (Days)", y = "Incidence", title = "Daily incidence") +
    theme_minimal() +
    theme(legend.position = "none")
  
  susceptibility_plot <- ggplot(combined_data, aes(x = time, color = param_value)) +
    geom_line(aes(y = S), size = 0.7) +
    labs(x = "Calendar time (Days)", y = "Susceptible count", title = "Susceptible population") +
    theme_minimal() +
    theme(legend.position = "none")
  
  forward_gi_plot <- ggplot(combined_data, aes(x = time, color = param_value)) +
    geom_line(aes(y = forward), size = 0.7) +
    geom_line(aes(y = intrinsic), linetype = "dashed", size = 0.8) +
    labs(x = "Calendar time (Days)", y = "Mean generation time (Days)", title = "Forward generation interval mean") +
    coord_cartesian(ylim = c(7.5, 10)) +
    xlim(0.1, 250) +
    theme_minimal() +
    theme(legend.position = "none")
  
  backward_gi_plot <- ggplot(combined_data, aes(x = time, color = param_value)) +
    geom_line(aes(y = backward), na.rm = TRUE, size = 0.7) +
    geom_line(aes(y = intrinsic), linetype = "dashed", na.rm = TRUE, size = 0.8) +
    labs(x = "Calendar time (Days)", y = "Mean generation time (Days)", title = "Backward generation interval mean") +
    ylim(0, 20) +
    xlim(0.1, 250) +
    theme_minimal() +
    theme(legend.position = "none")
  
  
  # Extract the legend from one of the plots
  plot_with_legend <- ggplot(combined_data, aes(x = time, color = param_value)) +
    geom_line(aes(y = i)) +
    labs(x = "Time (Days)", y = "Values", color = legend_title) +
    theme_minimal() +
    theme(legend.position = "bottom")
  
  get_only_legend <- function(plot) { 
    plot_table <- ggplot_gtable(ggplot_build(plot)) 
    legend_plot <- which(sapply(plot_table$grobs, function(x) x$name) == "guide-box") 
    legend <- plot_table$grobs[[legend_plot]] 
    return(legend) 
  }
  
  legend <- get_only_legend(plot_with_legend)
  
  # Combine and display different plot combinations
  # 1. Forward and Backwards
  forward_backward_plots <- arrangeGrob(
    forward_gi_plot, backward_gi_plot,
    ncol = 2
  )
  print(grid.arrange(forward_backward_plots, legend, nrow = 2, heights = c(10, 1)))
  
  # 2. Forward and Susceptible
  forward_susceptible_plots <- arrangeGrob(
    forward_gi_plot, susceptibility_plot,
    ncol = 2
  )
  print(grid.arrange(forward_susceptible_plots, legend, nrow = 2, heights = c(10, 1)))
  
  # 3. Backwards and Incidence
  backward_incidence_plots <- arrangeGrob(
    backward_gi_plot, incidence_plot,
    ncol = 2
  )
  print(grid.arrange(backward_incidence_plots, legend, nrow = 2, heights = c(10, 1)))
  
  # Combined plots
  combined_plots <- arrangeGrob(
    incidence_plot,
    susceptibility_plot,
    backward_gi_plot,
    forward_gi_plot,
    ncol = 2
  )
  
  plot_title <- paste("Effect of altering", param_name, "(Initial =", initial_value,") on Realized Generation Intervals.")
  
  final_plot <- grid.arrange(
    arrangeGrob(
      combined_plots,
      ncol = 1,
      top = textGrob(plot_title, gp = gpar(fontsize = 18, font = 3))
    ),
    legend,
    nrow = 2,
    heights = c(10, 1)
  )
  
  print(final_plot)
}



#Guide for Use:
#Define Initial Parameter conditions:
   #Define initial parameters under initial
   #Set m to 0 if no changes are needed
   #m is the change that occurs time steps day, or 10 0.1 time steps.
   #t is the time step when the change first begins to occur.
   #i specified the number of time steps change will occur for, set to 0.1 if instantaneous change.
   #set revert_to_zero = TRUE if you want vaccination to occur only for a few/1 time steps, otherwise rate will persist.
#Use plot_gi_means to iterate:
   #Specify the epidemic parameter to be altered (E.g. Beta)
   #Specify the values that the modification parameter will take (as a vector)
   #Specify the modification parameter (E.g. m, the slope parameter)
# Define initial parameters for beta, sigma, gamma, and lambda. (set for mid peak intervention)
parameters <- list(
  beta = list(initial = 0.5, m = 0, t = 60, i = 0.1),
  sigma = list(initial = 0.2, m = 0, t = 60, i = 0.1),
  gamma = list(initial = 0.2, m = 0, t = 60, i = 0.1),
  lambda = list(initial = 0, m = 0, t = 60, i = 0.1, revert_to_zero = FALSE)
)

# Define initial parameters for beta, sigma, gamma, and lambda. (set for different initial conditions)
#parameters <- list(
#  beta = list(initial = 1, m = 0, t = 0 i = 0.1),
#  sigma = list(initial = 0.2, m = 0, t = 0, i = 0.1),
#  gamma = list(initial = 0.2, m = 0, t = 0, i = 0.1),
#  lambda = list(initial = 0, m = 0, t = 0, i = 0.1, revert_to_zero = TRUE)
#)

# Initial state
state <- c(S = 99999, E = 1, I = 0, R = 0)

#Iterating over different m values for beta
#beta_m_values <- c(0, -0.1, -0.2, -0.3)
#plot_gi_means("beta", beta_m_values, "m")

# Example: Iterating over different t values for sigma
#sigma_t_values <- c(0, 50, 100, 150, 100)
#plot_gi_means("sigma", sigma_t_values, "t")

# Example: Iterating over different m values for gamma
gamma_m_values <- c(0)
plot_gi_means("gamma", gamma_m_values, "m")

