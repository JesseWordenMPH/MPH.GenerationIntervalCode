library(deSolve)
library(ggplot2)
library(reshape2)
library(gridExtra)

# Function that specifies SEIR differential equations 
seir_diff_fn <- function(t, state, parameters) {
  with(as.list(c(t, state, parameters)), { # Converts list to individual variables
    beta <- beta_fn(t)
    sigma <- sigma_fn(t)
    lamda <- lamda_fn(t)
    
    dS <- -( (beta / N) * S * I ) - lamda * S 
    dE <- (beta / N) * S * I - sigma * E
    dI <- sigma * E - gamma * I
    dR <- gamma * I + lamda * S
    list(c(dS, dE, dI, dR))
  })
}

# Simulation function
simulate_seir <- function(initial_value, params, start, end) {
  params$beta_fn <- approxfun(params$beta_events$time, params$beta_events$value, method="constant", rule=2)
  params$sigma_fn <- approxfun(params$sigma_events$time, params$sigma_events$value, method="constant", rule=2)
  params$lamda_fn <- approxfun(params$lamda_events$time, params$lamda_events$value, method="constant", rule=2)
  
  result <- list()
  result$overview <- data.frame(ode(
    y = initial_value,
    func = seir_diff_fn,
    times = seq(start, end, by=0.1),
    parms = params
  ))
  
  result$overview <- calculate_incidence(result$overview, params)
  result$params <- params
  
  result$beta <- params$beta_fn
  result$sigma <- params$sigma_fn
  result$lamda <- params$lamda_fn
  
  result$events <- tail(params$beta_events, -1) # Everything except the first
  
  # Set up approximation/step functions for S, E, I, R, incidence.
  result$S <- approxfun(result$overview$time, result$overview$S, yright=0, rule=2)
  result$E <- approxfun(result$overview$time, result$overview$E, rule=2)
  result$I <- approxfun(result$overview$time, result$overview$I, rule=2)
  result$R <- approxfun(result$overview$time, result$overview$R, rule=2)
  result$i <- approxfun(result$overview$time, result$overview$incidence, rule=2)
  
  return(result)
}

calculate_incidence <- function(df, params) {
  beta_fn <- params$beta_fn
  N <- params$N
  df$incidence <- mapply(function(t, S, I) {
    beta <- beta_fn(t)
    (beta * S * I) / N
  }, df$time, df$S, df$I)
  df
}

# Generation Interval Calculations

# Function that calculates the expected values of a probability dist
expectation <- function(fn) {
  integrate(function(x) x * fn(x), 0, 1000)$value
}

# Function that returns the Intrinsic Generation Interval Distribution
intrinsic_gt <- function(t, tau, sigma_fn, gamma) {
  sigma <- sigma_fn(t)
  
  if (sigma == gamma) {
    # Erlang distribution with k = 2 and rate lambda = sigma = gamma
    result <- (sigma^2) * tau * exp(-sigma * tau)
  } else {
    # Hypoexponential distribution with rates sigma and gamma
    result <- (sigma * gamma) * (exp(-gamma * tau) - exp(-sigma * tau)) / (sigma - gamma)
  }
  
  return(result)
}
# Helper function that performs part of computation for fGI and bGI calculations.
# Define g0_fn allows iGI to be computed without repeatedly needed to specify sigma and gamma.
g0_fn <- function(t, tau) intrinsic_gt(t, tau, simulation$sigma, parameters$gamma)

# Function that returns the forward generation interval distribution.
forward_gt <- function(t, tau, beta_fn, S_fn, g0_fn) {
  num <- g0_fn(t, tau) * beta_fn(t + tau) * S_fn(t + tau)
  denom <- integrate(
    function(rho) g0_fn(t, rho) * beta_fn(t + rho) * S_fn(t + rho),
    0,
    1000 
  )$value
  
  if (denom <= 0) {
    return(0)
  }
  
  num / denom
}

# Function that returns the backwards generation time distribution
backward_gt <- function(t, tau, incidence_fn, g0_fn) {
  num <- g0_fn(t, tau) * incidence_fn(t - tau)
  denom <- integrate(
    function(rho) g0_fn(t, rho) * incidence_fn(t - rho),
    0,
    t
  )$value
  
  if (denom <= 0) {
    return(0)
  }
  
  num / denom
}

# Specifying Parameters and Running Simulation

# Specifying parameters
# Data frames containing changes to parameters at timesteps.
beta_events <- data.frame(
  time   = c(0),
  value  = c(0.5)
)
lamda_events <- data.frame(
  time   = c(0), # Note, 0.1 time steps.
  value  = c(0)
)
sigma_events <- data.frame(
  time   = c(0),
  value  = c(0.2)
)
# Adding parameters to list
parameters <- list(N = 100000, beta_events = beta_events, sigma_events = sigma_events, gamma = 0.2, lamda_events = lamda_events)
state  <- c(S = 99999, E = 1, I = 0, R = 0) # Specifies Initial model state

calculate_deviations <- function(simulation) {
  # Calculate intrinsic mean generation time
  g0_mean <- function(t) expectation(function(tau) g0_fn(t, tau))
  
  # Store in the simulation result for use in other calculations
  simulation$g0 <- g0_fn
  
  # Time points for forward and backward generation times
  gfs <- data.frame(time = seq(0, 300, by = 1))
  
  # Calculate intrinsic generation time mean
  gfs$intrinsic <- sapply(gfs$time, g0_mean)
  
  # Calculate forward generation time mean
  gfs$forward <- sapply(gfs$time, function(t) {
    expectation(function(tau) forward_gt(t, tau, simulation$beta, simulation$S, g0_fn))
  })
  
  #The following code is to address a bug in the code that causes the forwards GI to drop off far into simulations, like due to a floating point error (I.e. I cant fix it the bug, so this is the best we can do.
  #This code specifies a valid time window around the epidemic peak to check for the minimum forward GI.
  # Time of epidemic peak
  peak_time <- gfs$time[which.max(simulation$i(gfs$time))]
  # Valid window around epidemic peak (+-30)
  proximity_window <- gfs$time >= (peak_time - 30) & gfs$time <= (peak_time + 30)
  # Filter forward GI values within this window
  forward_in_proximity <- gfs$forward[proximity_window]
  time_in_proximity <- gfs$time[proximity_window]
  # Find local minimum within the proximity window
  local_min_index <- which.min(forward_in_proximity)
  forward_min_near_peak <- forward_in_proximity[local_min_index]
  forward_min_time <- time_in_proximity[local_min_index]
  # Calculate the deviation from the intrinsic GI
  forward_max_dev_abs <- abs(gfs$intrinsic[forward_min_time == gfs$time] - forward_min_near_peak)
  
  # Calculate backward GI deviations as before
  gfs$backward <- sapply(gfs$time, function(t) {
    expectation(function(tau) backward_gt(t, tau, simulation$i, g0_fn))
  })
  
  # Maximum Deviation at plateau 1 for the backwards generation Interval
  # Identifying the indices where intrinsic > backward
  valid_indices <- which(gfs$intrinsic > gfs$backward)
  # Calculate the gradients for the valid points
  valid_gradients <- diff(gfs$backward[valid_indices]) / diff(gfs$time[valid_indices])
  # Find the index of the point where the gradient is closest to zero
  plateau_index <- valid_indices[which.min(abs(valid_gradients)) + 1]
  # Calculate the absolute difference at the identified plateau time
  backward_plateau1_dev_abs <- abs(gfs$intrinsic[plateau_index] - gfs$backward[plateau_index])
  
  # Maximum Deviation at plateau 2 for the backwards generation Interval
  backward_plateau2_dev_abs <- abs(gfs$intrinsic[which.max(gfs$time)] - gfs$backward[which.max(gfs$time)])
  
  return(list(
    forward_max_dev_abs = forward_max_dev_abs,
    backward_plateau1_dev_abs = backward_plateau1_dev_abs,
    backward_plateau2_dev_abs = backward_plateau2_dev_abs
  ))
}


# Values for sigma and gamma to iterate over
latent_period_values <- seq(1,10, by = 1)
sigma_values <- 1/latent_period_values
infectious_period_values <- seq(3,10, by = 1)
gamma_values <- 1/infectious_period_values

# Matrices to store results
forward_max_dev_abs_matrix <- matrix(0, nrow = length(sigma_values), ncol = length(gamma_values))
backward_plateau1_dev_abs_matrix <- matrix(0, nrow = length(sigma_values), ncol = length(gamma_values))
backward_plateau2_dev_abs_matrix <- matrix(0, nrow = length(sigma_values), ncol = length(gamma_values))
r0_matrix <- matrix(0, nrow = length(sigma_values), ncol = length(gamma_values))
sigma_matrix <- matrix(0, nrow = length(sigma_values), ncol = length(gamma_values))
gamma_matrix <- matrix(0, nrow = length(sigma_values), ncol = length(gamma_values))

# Loop over values of sigma and gamma
for (i in seq_along(sigma_values)) {
  for (j in seq_along(gamma_values)) {
    sigma <- sigma_values[i]
    gamma <- gamma_values[j]
    
    # Calculate R0 for the current beta, sigma, and gamma values
    r0 <- parameters$beta_events$value[1] / gamma
    
    # Condition 1: If R0 < 1.5, set all deviations to NA and skip calculation
    if (r0 < 1) {
      forward_max_dev_abs_matrix[i, j] <- NA
      backward_plateau1_dev_abs_matrix[i, j] <- NA
      backward_plateau2_dev_abs_matrix[i, j] <- NA
    } else {
      # Update parameters
      parameters$sigma_events$value <- sigma
      parameters$gamma <- gamma
      
      # Run simulation
      simulation <- simulate_seir(
        initial_value = state,
        params = parameters,
        start = 0,
        end = 400
      )
      
      # Calculate deviations (and generation interval means)
      deviations <- calculate_deviations(simulation)
      
      # Store results in matrices
      forward_max_dev_abs_matrix[i, j] <- deviations$forward_max_dev_abs
      backward_plateau1_dev_abs_matrix[i, j] <- deviations$backward_plateau1_dev_abs
      
      # Condition 2: If R0 > 5, set backward_plateau2_dev_abs_matrix to NA
      if (r0 > 5) {
        backward_plateau2_dev_abs_matrix[i, j] <- NA
      } else {
        backward_plateau2_dev_abs_matrix[i, j] <- deviations$backward_plateau2_dev_abs
      }
    }
    
    # Store R0, sigma, and gamma values
    r0_matrix[i, j] <- r0
    sigma_matrix[i, j] <- sigma
    gamma_matrix[i, j] <- gamma
    
    # Print progress
    cat("Completed sigma =", sigma, "gamma =", gamma, "\n")
  }
}



# Print matrices
print(forward_max_dev_abs_matrix)
print(backward_plateau1_dev_abs_matrix)
print(backward_plateau2_dev_abs_matrix)
print(r0_matrix)
print(sigma_matrix)
print(gamma_matrix)

# plotting code

# Define the function to create a heatmap
create_heatmap <- function(matrix_data, latent_period_values, infectious_period_values, title) {
  # Convert the matrix to a data frame for ggplot2
  matrix_df <- melt(matrix_data)
  
  # Adjust the column names to be more descriptive
  colnames(matrix_df) <- c("latent_period", "infectious_period", "value")
  
  # Replace the default numeric labels with custom labels
  matrix_df$latent_period <- factor(matrix_df$latent_period, levels = seq_along(latent_period_values), labels = latent_period_values)
  matrix_df$infectious_period <- factor(matrix_df$infectious_period, levels = seq_along(infectious_period_values), labels = infectious_period_values)
  
  # Create the heatmap using ggplot2
  heatmap <- ggplot(matrix_df, aes(x = infectious_period, y = latent_period, fill = value)) +
    geom_tile() +
    scale_fill_gradient(low = "white", high = "blue", na.value = "grey") +
    theme_minimal() +
    labs(title = title,
         x = "Infectious period (days)",
         y = "Latent period (days)",
         fill = "Deviation")
  
  return(heatmap)
}


# Generate each heatmap individually
forward_heatmap <- create_heatmap(forward_max_dev_abs_matrix, latent_period_values, infectious_period_values, "Forward GI minimum mean")
backward1_heatmap <- create_heatmap(backward_plateau1_dev_abs_matrix, latent_period_values, infectious_period_values, "Backwards GI early-phase equilibirum")
backward2_heatmap <- create_heatmap(backward_plateau2_dev_abs_matrix, latent_period_values, infectious_period_values, "Backwards GI late-phase equilibrium")

# Arrange the three heatmaps in a single plot layout
grid.arrange(forward_heatmap, backward1_heatmap, backward2_heatmap, ncol = 3)
